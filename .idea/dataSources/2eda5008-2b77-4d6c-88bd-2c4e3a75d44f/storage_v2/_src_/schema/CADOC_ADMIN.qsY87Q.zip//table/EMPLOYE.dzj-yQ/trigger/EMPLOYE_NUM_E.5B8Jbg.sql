create trigger EMPLOYE_NUM_E
  before insert
  on EMPLOYE
  for each row
  when (NEW.Num_E IS NULL)
  BEGIN
		 select Seq_Employe_Num_E.NEXTVAL INTO :NEW.Num_E from DUAL;
	END;
/

