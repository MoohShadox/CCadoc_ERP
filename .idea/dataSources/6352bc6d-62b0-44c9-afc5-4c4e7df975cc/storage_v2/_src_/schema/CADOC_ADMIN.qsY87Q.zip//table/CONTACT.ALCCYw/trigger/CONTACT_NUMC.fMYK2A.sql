create trigger CONTACT_NUMC
  before insert
  on CONTACT
  for each row
  when (NEW.NumC IS NULL)
  BEGIN
		 select Seq_Contact_NumC.NEXTVAL INTO :NEW.NumC from DUAL;
	END;
/

